This dataset belongs to Doaa Alsenani
and can be found on Kaggle at the url:
https://www.kaggle.com/doaaalsenani/usa-cers-dataset

no copyright infringement intended!
for DMCA takedown please contact mathis.vaneetvelde@gmail.com
